package Table;

public class FuncTable {
}
