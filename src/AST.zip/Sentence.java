import Token.Token;

import java.util.ArrayList;

public class Sentence {
    private ArrayList<Token> tokens = new ArrayList<>();
    private String type = "";
}
